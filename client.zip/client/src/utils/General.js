
export const TabTitle = (newTitle) => {
    return ( document.title = newTitle);
}